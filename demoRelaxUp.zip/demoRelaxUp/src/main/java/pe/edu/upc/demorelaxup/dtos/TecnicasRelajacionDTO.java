package pe.edu.upc.demorelaxup.dtos;

public class TecnicasRelajacionDTO {
    private int idTecnicaRelajacion;
    private String nombreTecnica;

    public int getIdTecnicaRelajacion() {
        return idTecnicaRelajacion;
    }

    public void setIdTecnicaRelajacion(int idTecnicaRelajacion) {
        this.idTecnicaRelajacion = idTecnicaRelajacion;
    }

    public String getNombreTecnica() {
        return nombreTecnica;
    }

    public void setNombreTecnica(String nombreTecnica) {
        this.nombreTecnica = nombreTecnica;
    }
}
